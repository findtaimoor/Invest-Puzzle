import React from "react";
import { Alert } from "react-bootstrap";

const Message = ({ children, variant = "danger" }) => {
  return (
    <Alert variant={variant} className="text-center">
      {children}
    </Alert>
  );
};

export default Message;
