import React from "react";

const StepCheck = ({ name }) => {
  return (
    <>
      <h1 className="checkout-link1 pt-3">{name}</h1>
    </>
  );
};

export default StepCheck;
