import React from 'react'

const AdminDashboard = () => {
  return (
<>
<h1 className='admin-main text-center'>
    This is Admin Dashboard.
</h1>
</>  )
}

export default AdminDashboard